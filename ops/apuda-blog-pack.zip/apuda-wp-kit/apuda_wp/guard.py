"""Checks a draft must pass before it is posted (even as a WordPress draft).

The rules follow ApuDa's content rules: no number that is not in the reviewed
FAQ text, no absolute or prescriptive claims, the patient notice and the link
back to apuda.app are always present.
"""
import re

BANNED = ["완치", "보장", "100%", "부작용 없", "부작용이 없", "확실히 낫", "반드시 낫", "특효",
          "효과 입증", "전문의 감수 완료", "검증된 치료법", "복용하세요", "처방합니다", "진단합니다"]
WORD_MIRACLE = re.compile(r"(?<![가-힣])기적")
NUMBER = re.compile(r"\d+(?:[.,]\d+)?")


def _numbers(text):
    return {n.replace(",", "") for n in NUMBER.findall(text)}


def draft_text(draft):
    parts = [draft.get("title", ""), draft.get("excerpt", "")]
    parts.extend(draft.get("reader_questions") or [])
    parts.extend(draft.get("intro") or [])
    km = draft.get("key_message") or ""
    parts.extend(km if isinstance(km, list) else [km])
    parts.extend(draft.get("hashtags") or [])
    for section in draft.get("sections", []):
        parts.append(section.get("heading", ""))
        parts.extend(section.get("paragraphs", []))
    parts.extend(draft.get("questions_for_visit", []))
    return "\n".join(parts)


def check(draft, topic):
    """Return a list of problems. Empty list means the draft may be posted."""
    problems = []
    text = draft_text(draft)
    source = "\n".join([topic.cancer_name, topic.title, topic.summary] +
                       [i.q + "\n" + i.a for i in topic.items])

    allowed = _numbers(source) | {str(len(topic.items))}
    stray = sorted(_numbers(text) - allowed)
    if stray:
        problems.append("FAQ 원문에 없는 숫자: " + ", ".join(stray))

    for word in BANNED:
        if word in text:
            problems.append("금지 표현: " + word)
    # '기적'은 단어 앞에 다른 글자가 붙으면(정기적·주기적·일시적…) 금지어가 아님
    if WORD_MIRACLE.search(text):
        problems.append("금지 표현: 기적")

    if not draft.get("title") or len(draft["title"]) > 70:
        problems.append("제목이 없거나 70자를 넘음")
    sections = draft.get("sections", [])
    if not 2 <= len(sections) <= 8:
        problems.append(f"섹션 수 {len(sections)}개 (2~8개여야 함)")
    if len(draft.get("questions_for_visit") or []) > 10:
        problems.append("진료실 질문이 10개를 넘음")
    if len(text) < 300:
        problems.append("본문이 너무 짧음")

    known = {i.n for i in topic.items}
    used = set(draft.get("used_items") or [])
    if not used or not used <= known:
        problems.append("used_items가 비었거나 주제 밖 번호를 포함")
    return problems
