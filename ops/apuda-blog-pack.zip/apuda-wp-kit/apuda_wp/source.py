"""Read ApuDa FAQ topics from a local checkout of the Mespital/ApuDa repo.

Only reviewed-and-published FAQ data is used: public-site/library/faq/data/<slug>.json
and the editorial topic maps in public-site/scripts/faq-topics/<slug>.json.
Nothing here writes to the repo.
"""
import json
from dataclasses import dataclass, field
from pathlib import Path

SITE = "https://apuda.app"


@dataclass
class Item:
    n: int
    q: str
    a: str
    sources: list = field(default_factory=list)  # [{"title", "url", "organization"}]


@dataclass
class Topic:
    cancer_slug: str
    cancer_name: str
    topic_slug: str
    title: str
    summary: str
    updated: str
    items: list

    @property
    def key(self):
        return f"{self.cancer_slug}/{self.topic_slug}"

    @property
    def page_url(self):
        return f"{SITE}/library/faq/{self.cancer_slug}/{self.topic_slug}/"

    @property
    def hub_url(self):
        return f"{SITE}/library/faq/{self.cancer_slug}/"

    def source_list(self):
        seen, out = set(), []
        for item in self.items:
            for src in item.sources:
                if src["url"] not in seen:
                    seen.add(src["url"])
                    out.append(src)
        return out


def load_topics(repo: Path):
    site = Path(repo) / "public-site"
    topics = []
    for map_file in sorted((site / "scripts" / "faq-topics").glob("*.json")):
        topic_map = json.loads(map_file.read_text(encoding="utf-8"))
        faq = json.loads((site / "library" / "faq" / "data" / f"{topic_map['slug']}.json").read_text(encoding="utf-8"))
        by_n = {int(item["n"]): item for item in faq["items"]}
        for topic in topic_map["topics"]:
            items = []
            for n in topic["items"]:
                raw = by_n[n]
                refs = raw.get("review", {}).get("sourceRefs", [])
                srcs = [
                    {k: faq["sources"][r][k] for k in ("title", "url", "organization")}
                    for r in refs
                    if r in faq["sources"] and faq["sources"][r].get("url", "").startswith("https://")
                ]
                items.append(Item(n=n, q=raw["q"], a=raw["a"], sources=srcs))
            topics.append(Topic(faq["slug"], faq["name"], topic["slug"], topic["title"],
                                topic["summary"], faq.get("updated", ""), items))
    return topics
