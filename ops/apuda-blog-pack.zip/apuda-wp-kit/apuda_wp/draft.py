"""Turn one FAQ topic into an article draft.

Two modes:
- ai:      Claude or Gemini API rewrites the topic's reviewed FAQ answers into an article.
           The prompt forbids any fact that is not in the given answers.
- outline: no API call. A short guide page: summary, the questions, and links
           back to apuda.app. Safe fallback and for testing.

Either way the result goes through guard.check() before it can be posted.
"""
import json
import os
import urllib.request

API_URL = "https://api.anthropic.com/v1/messages"
DEFAULT_MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5-5")
GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"

SYSTEM = """너는 아프다(ApuDa) 편집부의 환자교육 글 작성자다.
독자는 암 환자와 보호자다. 따뜻하고 차분하게, 정확하게 쓴다.

절대 규칙:
1. 아래 [FAQ 원문]에 있는 사실만 쓴다. 원문에 없는 수치·약 이름·기간·확률·효과·제도를 새로 넣지 않는다.
2. 숫자는 원문에 나온 그대로만 쓴다. 단위와 범위를 바꾸지 않는다.
3. 진단·처방·개인별 치료 권유를 하지 않는다. "~하세요"는 의료진에게 묻기·기록하기·연락하기에만 쓴다.
4. 완치·보장·100%·부작용 없음 같은 단정 표현을 쓰지 않는다.
5. 원문 문장을 그대로 옮기지 말고 글 흐름에 맞게 다시 쓴다. 다만 의미는 바꾸지 않는다.
6. 응급 판단 기준(체온 몇 도 등)은 쓰지 말고 "해당 증상은 치료팀에 바로 알리세요"까지만 쓴다.

출력은 JSON 하나만:
{"title": "...", "excerpt": "120자 이내 요약", "sections": [{"heading": "...", "paragraphs": ["...", "..."]}], "questions_for_visit": ["...", "...", "..."], "used_items": [FAQ 번호들]}
sections는 4~7개. 마지막 섹션 다음에 링크·출처·안내문은 프로그램이 붙이니 쓰지 않는다."""


def _topic_prompt(topic):
    lines = [f"[암종] {topic.cancer_name}", f"[주제] {topic.title}", f"[주제 요약] {topic.summary}", "", "[FAQ 원문]"]
    for item in topic.items:
        lines.append(f"#{item.n} Q: {item.q}")
        lines.append(f"A: {item.a}")
    return "\n".join(lines)


def draft_with_claude(topic, api_key=None, model=DEFAULT_MODEL):
    api_key = api_key or os.environ["ANTHROPIC_API_KEY"]
    body = json.dumps({
        "model": model,
        "max_tokens": 4000,
        "system": SYSTEM,
        "messages": [{"role": "user", "content": _topic_prompt(topic)}],
    }).encode("utf-8")
    req = urllib.request.Request(API_URL, data=body, method="POST", headers={
        "content-type": "application/json",
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
    })
    with urllib.request.urlopen(req, timeout=120) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    text = "".join(block.get("text", "") for block in data.get("content", []))
    return _json_from(text, "Claude")


def _json_from(text, who):
    start, end = text.find("{"), text.rfind("}")
    if start < 0 or end < 0:
        raise ValueError(who + " did not return JSON")
    return json.loads(text[start:end + 1])


def draft_with_gemini(topic, api_key=None, model=None):
    api_key = api_key or os.environ["GEMINI_API_KEY"]
    model = model or os.environ.get("GEMINI_MODEL", "gemini-3.8-flash")
    body = json.dumps({
        "systemInstruction": {"parts": [{"text": SYSTEM}]},
        "contents": [{"role": "user", "parts": [{"text": _topic_prompt(topic)}]}],
        "generationConfig": {"responseMimeType": "application/json", "temperature": 0.3, "maxOutputTokens": 16384},
    }).encode("utf-8")
    req = urllib.request.Request(GEMINI_URL.format(model=model), data=body, method="POST", headers={
        "content-type": "application/json",
        "x-goog-api-key": api_key,
    })
    with urllib.request.urlopen(req, timeout=180) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    parts = (data.get("candidates") or [{}])[0].get("content", {}).get("parts", [])
    text = "".join(p.get("text", "") for p in parts if not p.get("thought"))
    return _json_from(text, "Gemini")


def provider():
    """AI_PROVIDER=gemini|claude; otherwise whichever key is set (Claude first)."""
    choice = os.environ.get("AI_PROVIDER", "").strip().lower()
    if choice in ("gemini", "claude"):
        return choice
    if os.environ.get("ANTHROPIC_API_KEY"):
        return "claude"
    if os.environ.get("GEMINI_API_KEY"):
        return "gemini"
    raise RuntimeError("AI 키가 없음: .env에 GEMINI_API_KEY 또는 ANTHROPIC_API_KEY를 넣거나 --outline 사용")


def draft_with_ai(topic):
    return draft_with_gemini(topic) if provider() == "gemini" else draft_with_claude(topic)


def draft_outline(topic):
    return {
        "title": f"{topic.cancer_name} {topic.title}: 자주 묻는 질문 {len(topic.items)}가지",
        "excerpt": topic.summary[:120],
        "sections": [
            {"heading": "이 글에서 다루는 내용", "paragraphs": [
                topic.summary,
                "질문별 답변과 참고 자료는 아프다 FAQ에 정리돼 있습니다. 궁금한 질문을 골라 읽어 보세요."]},
            {"heading": "자주 묻는 질문", "paragraphs": [f"• {item.q}" for item in topic.items]},
        ],
        "questions_for_visit": [],
        "used_items": [item.n for item in topic.items],
    }
