"""Blog images, built with the ApuDa book-figure renderer (apuda-book-figures skill).

- cover:     Gemini image model draws a calm, text-free illustration; the program
             overlays the Korean title and the ApuDa signature. Featured image.
             If Gemini fails, a plain brand cover is drawn instead.
- flow:      '이 글의 흐름' step figure from the section headings (steps template).
- checklist: '진료실에서 확인할 질문' checklist from questions_for_visit.

Every word inside the figures comes from the guard-checked draft. The model that
draws the cover is told to put no text, numbers or logos in the picture.
"""
import base64
import io
import json
import os
import re
import urllib.request
from pathlib import Path

GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
COVER_CAPTION = "AI로 만든 개념 일러스트이며 실제 해부 구조나 검사 장면과 다를 수 있습니다."

IMAGE_PROMPT = """Create a calm, clean 3D medical illustration for a Korean patient-education blog about {cancer} ({topic}).
Scene idea: {scene}
Style: soft studio lighting, simplified anatomy as a concept diagram, deep blue (#0B5FA5) and white palette with a small warm gold accent,
gentle and hopeful mood, generous empty space in the lower third for a title overlay, 16:9 landscape.
Strict rules: absolutely NO text, letters, numbers, labels, logos or watermarks anywhere in the image.
No blood, gore, wounds, needles in skin, surgery scenes, skulls, frightening tumors or close-ups of cancer cells. No real people's faces."""


def _first_sentence(paragraphs, limit=58):
    for p in paragraphs:
        if p and not p.startswith("• "):
            s = re.split(r"(?<=[.?!다요])\s", p.strip())[0]
            return s if len(s) <= limit else s[:limit - 1] + "…"
    return ""


def gemini_image(prompt, api_key=None, model=None):
    api_key = api_key or os.environ["GEMINI_API_KEY"]
    model = model or os.environ.get("GEMINI_IMAGE_MODEL", "gemini-3.1-flash-image")
    body = json.dumps({
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {"responseModalities": ["IMAGE"], "imageConfig": {"aspectRatio": "16:9"}},
    }).encode("utf-8")
    req = urllib.request.Request(GEMINI_URL.format(model=model), data=body, method="POST", headers={
        "content-type": "application/json", "x-goog-api-key": api_key})
    with urllib.request.urlopen(req, timeout=180) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    for part in (data.get("candidates") or [{}])[0].get("content", {}).get("parts", []):
        inline = part.get("inlineData") or part.get("inline_data")
        if inline and inline.get("data"):
            return base64.b64decode(inline["data"])
    raise RuntimeError("Gemini 이미지 응답에 그림이 없음")


def _cover(draft, topic, art_bytes, path):
    from PIL import Image, ImageDraw
    from .figures import apuda_render as R
    W, H = 1200, 675
    if art_bytes:
        art = Image.open(io.BytesIO(art_bytes)).convert("RGB")
        scale = max(W / art.width, H / art.height)
        art = art.resize((int(art.width * scale) + 1, int(art.height * scale) + 1))
        left, top = (art.width - W) // 2, (art.height - H) // 2
        img = art.crop((left, top, left + W, top + H))
    else:
        img = Image.new("RGB", (W, H), R.BLUE)
        g = ImageDraw.Draw(img)
        for y in range(H):  # soft vertical gradient
            t = y / H
            g.line([(0, y), (W, y)], fill=(int(11 + 30 * t), int(95 - 40 * t), int(165 - 60 * t)))
    # bottom band for the title
    band = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    bd = ImageDraw.Draw(band)
    for y in range(int(H * 0.42), H):
        a = int(225 * min(1, (y - H * 0.42) / (H * 0.25)))
        bd.line([(0, y), (W, y)], fill=(8, 40, 80, a))
    img = Image.alpha_composite(img.convert("RGBA"), band).convert("RGB")
    d = ImageDraw.Draw(img)
    f = lambda w, s: R.ImageFont.truetype(R._find_font(w), s, index=R._KR_INDEX if R._find_font(w).endswith(".ttc") else 0)
    pill = f"ApuDa {topic.cancer_name} · {topic.title.split('·')[0]}"
    pf = f("Bold", 26)
    pw = d.textlength(pill, font=pf)
    d.rounded_rectangle([60, H - 250, 60 + pw + 36, H - 206], radius=22, fill=R.GOLD)
    d.text((78, H - 228), pill, font=pf, fill=R.INK, anchor="lm")
    tf = f("Bold", 50)
    lines, cur = [], ""
    for word in draft["title"].split(" "):
        test = (cur + " " + word).strip()
        if d.textlength(test, font=tf) > W - 120 and cur:
            lines.append(cur)
            cur = word
        else:
            cur = test
    lines.append(cur)
    lines = lines[:2]
    y = H - 185
    for ln in lines:
        d.text((60, y), ln, font=tf, fill=(255, 255, 255))
        y += 64
    sf = f("Bold", 24)
    d.text((W - 60, 48), "ApuDa 아프지만, 다행이다", font=sf, fill=(255, 255, 255), anchor="ra")
    img.save(path, "JPEG", quality=88)
    return path


def make_images(draft, topic, outdir):
    """Return a list of dicts: role, path, alt, caption. Skips any figure that fails."""
    from .figures.render_spec import RENDER
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    base = f"{topic.cancer_slug}-{topic.topic_slug}"
    out, warnings = [], []

    art = None
    if os.environ.get("GEMINI_API_KEY") and os.environ.get("IMAGE_AI", "1") != "0":
        scene = (draft.get("image_scene") or f"{topic.cancer_name} {topic.title}").strip()
        try:
            art = gemini_image(IMAGE_PROMPT.format(cancer=topic.cancer_name, topic=topic.title, scene=scene))
        except Exception as exc:  # noqa: BLE001
            warnings.append(f"표지 AI 그림 실패({type(exc).__name__}: {exc}) → 기본 표지 사용")
    path = _cover(draft, topic, art, outdir / f"{base}-cover.jpg")
    out.append({"role": "cover", "path": str(path), "alt": draft["title"],
                "caption": COVER_CAPTION if art else ""})

    steps = [{"head": s["heading"], "sub": _first_sentence(s["paragraphs"])} for s in draft["sections"]][:7]
    if len(steps) >= 2:
        p = outdir / f"{base}-flow.png"
        RENDER["steps"]({"type": "steps", "title": f"{topic.cancer_name} {topic.title.split('·')[0]}, 이 글의 흐름",
                         "subtitle": draft.get("excerpt", "")[:80], "steps": steps}, str(p))
        out.append({"role": "flow", "path": str(p), "alt": "이 글의 흐름: " + " / ".join(s["head"] for s in steps), "caption": ""})

    qs = [q for q in draft.get("questions_for_visit") or [] if q][:6]
    if qs:
        p = outdir / f"{base}-questions.png"
        RENDER["checklist"]({"type": "checklist", "title": "진료실에서 확인할 질문", "items": qs, "narrow": True}, str(p))
        out.append({"role": "questions", "path": str(p), "alt": "진료실에서 확인할 질문: " + " / ".join(qs), "caption": ""})
    return out, warnings
