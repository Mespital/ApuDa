"""Render a checked draft as WordPress (Gutenberg) block HTML.

The program, not the model, adds: the apuda.app links, the source list taken
from the FAQ records, the review-status notice and the date.
"""
from html import escape

NOTICE = ("이 글은 아프다 FAQ(자료 업데이트 {updated})를 바탕으로 한 환자교육용 참고정보입니다. "
          "문항별 전문의 검토는 완료되지 않았으며, 진단·처방·개인별 치료 결정을 대신하지 않습니다. "
          "국내 허가·급여 기준과 병원별 안내는 다를 수 있으니 담당 의료진과 상의하세요.")


def _p(text):
    return f"<!-- wp:paragraph -->\n<p>{escape(text)}</p>\n<!-- /wp:paragraph -->"


def _h(text, level=2):
    return f'<!-- wp:heading {{"level":{level}}} -->\n<h{level} class="wp-block-heading">{escape(text)}</h{level}>\n<!-- /wp:heading -->'


def _list(items, links=False):
    lis = "".join(f'<!-- wp:list-item -->\n<li>{i}</li>\n<!-- /wp:list-item -->' for i in items)
    return f"<!-- wp:list -->\n<ul class=\"wp-block-list\">{lis}</ul>\n<!-- /wp:list -->"


def render(draft, topic):
    out = [_p(draft.get("excerpt", ""))]
    for section in draft["sections"]:
        out.append(_h(section["heading"]))
        bullets = [p for p in section["paragraphs"] if p.startswith("• ")]
        prose = [p for p in section["paragraphs"] if not p.startswith("• ")]
        out.extend(_p(p) for p in prose)
        if bullets:
            out.append(_list([escape(b[2:]) for b in bullets]))
    if draft.get("questions_for_visit"):
        out.append(_h("진료실에서 물어볼 질문"))
        out.append(_list([escape(q) for q in draft["questions_for_visit"]]))
    out.append(_h("더 읽기"))
    out.append(_list([
        f'<a href="{topic.page_url}">{escape(topic.cancer_name + " " + topic.title)} FAQ {len(topic.items)}문항 (아프다)</a>',
        f'<a href="{topic.hub_url}">{escape(topic.cancer_name)} FAQ 100문항 전체 보기</a>',
    ]))
    sources = topic.source_list()
    if sources:
        out.append(_h("참고 자료", 3))
        out.append(_list([f'<a href="{escape(s["url"])}" rel="nofollow noopener">{escape(s["title"])}</a>' for s in sources]))
    out.append("<!-- wp:separator -->\n<hr class=\"wp-block-separator has-alpha-channel-opacity\"/>\n<!-- /wp:separator -->")
    out.append(_p(NOTICE.format(updated=topic.updated or "미확인")))
    return "\n\n".join(out)
