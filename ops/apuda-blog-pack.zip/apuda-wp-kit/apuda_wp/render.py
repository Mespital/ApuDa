"""Render a checked draft as WordPress (Gutenberg) block HTML.

Layout (ApuDa blog format):
  series line → reader-question quote → intro → numbered sections →
  진료실에서 확인할 질문 (①②③) → 핵심 메시지 →
  ApuDa footer quote → apuda.app link card → 더 읽기 →
  ※ notice + 참고자료 → hashtags

The program, not the model, adds the footer, links, sources, notice and date.
"""
import re
from html import escape

CIRCLED = "①②③④⑤⑥⑦⑧⑨⑩"
SITE = "https://apuda.app/"

NOTICE = ("※ 본 글은 공식 의학 근거 기반 환자교육용 정보입니다. "
          "개인별 진단과 치료는 담당 의료진과 상의하시기 바랍니다.")
REVIEW = ("아프다 FAQ(자료 업데이트 {updated})를 바탕으로 정리했으며, 문항별 전문의 검토는 아직 완료되지 않았습니다. "
          "국내 허가·급여 기준과 병원별 안내는 다를 수 있습니다.")

CARD = ('<!-- wp:paragraph {"style":{"color":{"background":"#f3f6fb"}}} -->\n'
        '<p class="has-background" style="background-color:#f3f6fb">'
        '<a href="{site}"><strong>아프다 ApuDa | 암 정보와 환자·보호자 길잡이</strong></a><br>'
        '아프지만, 다행이다. 암 진단 첫 30일 안내서·FAQ·환자 카페·패밀리 서비스.<br>'
        '<a href="{site}">apuda.app</a></p>\n<!-- /wp:paragraph -->')


def _eul(word):
    """을/를 by the last syllable's final consonant."""
    ch = word[-1:] or "암"
    code = ord(ch) - 0xAC00
    if 0 <= code <= 11171:
        return "을" if code % 28 else "를"
    return "을"


def _p(text, raw=False, cls=""):
    body = text if raw else escape(text)
    attr = f' class="{cls}"' if cls else ""
    return f"<!-- wp:paragraph -->\n<p{attr}>{body}</p>\n<!-- /wp:paragraph -->"


def _h(text, level=2):
    return f'<!-- wp:heading {{"level":{level}}} -->\n<h{level} class="wp-block-heading">{escape(text)}</h{level}>\n<!-- /wp:heading -->'


def _list(items):
    lis = "".join(f'<!-- wp:list-item -->\n<li>{i}</li>\n<!-- /wp:list-item -->' for i in items)
    return f"<!-- wp:list -->\n<ul class=\"wp-block-list\">{lis}</ul>\n<!-- /wp:list -->"


def _quote(lines_html):
    body = "<br>".join(lines_html)
    return ('<!-- wp:quote {"className":"is-style-plain"} -->\n'
            '<blockquote class="wp-block-quote is-style-plain"><!-- wp:paragraph {"align":"center"} -->\n'
            f'<p class="has-text-align-center">{body}</p>\n<!-- /wp:paragraph --></blockquote>\n<!-- /wp:quote -->')


def _tag(word):
    return re.sub(r"[\s#·,./]+", "", str(word))


def hashtags(draft, topic):
    words = [topic.cancer_name] + list(draft.get("hashtags") or []) + ["아프다", "APUDA"]
    out, seen = [], set()
    for w in words:
        t = _tag(w)
        if t and t not in seen:
            seen.add(t)
            out.append(t)
    return out[:14]


def render(draft, topic):
    out = [_p(f"ApuDa {topic.cancer_name}, {topic.title}", cls="has-small-font-size")]

    rq = [q for q in (draft.get("reader_questions") or []) if q][:3]
    if rq:
        out.append(_quote([escape("“" + q.strip("“”\" ") + "”") for q in rq]))
    for para in draft.get("intro") or [draft.get("excerpt", "")]:
        if para:
            out.append(_p(para))

    n = 0
    for section in draft["sections"]:
        n += 1
        out.append(_h(f"{n}. {section['heading']}"))
        bullets = [p for p in section["paragraphs"] if p.startswith("• ")]
        prose = [p for p in section["paragraphs"] if not p.startswith("• ")]
        out.extend(_p(p) for p in prose)
        if bullets:
            out.append(_list([escape(b[2:]) for b in bullets]))

    qs = [q for q in (draft.get("questions_for_visit") or []) if q][:len(CIRCLED)]
    if qs:
        n += 1
        out.append(_h(f"{n}. 진료실에서 확인할 질문"))
        out.append(_p("<br>".join(f"{CIRCLED[i]} {escape(q)}" for i, q in enumerate(qs)), raw=True))

    if draft.get("key_message"):
        out.append(_h("이번 글의 핵심 메시지", 3))
        msg = draft["key_message"]
        for para in (msg if isinstance(msg, list) else [msg]):
            out.append(_p(para))

    out.append("<!-- wp:separator -->\n<hr class=\"wp-block-separator has-alpha-channel-opacity\"/>\n<!-- /wp:separator -->")
    out.append(_quote([
        "<em>ApuDa | 아프지만, 다행이다.</em>",
        escape(f"{topic.cancer_name}{_eul(topic.cancer_name)} 비롯한 다양한 암종의 환자교육 자료와"),
        "최신 암 관련 뉴스를 확인하세요.",
    ]))
    out.append(CARD.replace("{site}", SITE))

    out.append(_list([
        f'<a href="{topic.page_url}">{escape(topic.cancer_name + " " + topic.title)} FAQ {len(topic.items)}문항 (아프다)</a>',
        f'<a href="{topic.hub_url}">{escape(topic.cancer_name)} FAQ 100문항 전체 보기</a>',
    ]))

    notice = [escape(NOTICE), escape(REVIEW.format(updated=topic.updated or "미확인"))]
    sources = topic.source_list()
    if sources:
        refs = ", ".join(f'<a href="{escape(s["url"])}" rel="nofollow noopener">{escape(s["title"])}</a>' for s in sources)
        notice.append("참고자료: " + refs)
    out.append(_p("<br>".join(notice), raw=True, cls="has-small-font-size"))

    out.append(_p(" ".join("#" + escape(t) for t in hashtags(draft, topic)), raw=True))
    return "\n\n".join(out)
