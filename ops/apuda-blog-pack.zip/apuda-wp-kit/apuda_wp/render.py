"""Render a checked draft as WordPress (Gutenberg) block HTML.

Layout (ApuDa blog format):
  series line → reader-question quote → intro → numbered sections →
  진료실에서 확인할 질문 (①②③) → 핵심 메시지 →
  ApuDa footer quote → apuda.app link card → 더 읽기 →
  ※ notice + 참고자료 → hashtags

The program, not the model, adds the footer, links, sources, notice and date.
"""
import re
from html import escape

CIRCLED = "①②③④⑤⑥⑦⑧⑨⑩"
SITE = "https://apuda.app/"

NOTICE = ("※ 본 글은 공식 의학 근거 기반 환자교육용 정보입니다. "
          "개인별 진단과 치료는 담당 의료진과 상의하시기 바랍니다.")
REVIEW = ("아프다 FAQ(자료 업데이트 {updated})를 바탕으로 정리했으며, 문항별 전문의 검토는 아직 완료되지 않았습니다. "
          "국내 허가·급여 기준과 병원별 안내는 다를 수 있습니다.")

CARD = ('<!-- wp:paragraph {"style":{"color":{"background":"#f3f6fb"}}} -->\n'
        '<p class="has-background" style="background-color:#f3f6fb">'
        '<a href="{site}"><strong>아프다 ApuDa | 암 정보와 환자·보호자 길잡이</strong></a><br>'
        '아프지만, 다행이다. 암 진단 첫 30일 안내서·FAQ·환자 카페·패밀리 서비스.<br>'
        '<a href="{site}">apuda.app</a></p>\n<!-- /wp:paragraph -->')


def _eul(word):
    """을/를 by the last syllable's final consonant."""
    ch = word[-1:] or "암"
    code = ord(ch) - 0xAC00
    if 0 <= code <= 11171:
        return "을" if code % 28 else "를"
    return "을"


def _p(text, raw=False, cls=""):
    body = text if raw else escape(text)
    attr = f' class="{cls}"' if cls else ""
    return f"<!-- wp:paragraph -->\n<p{attr}>{body}</p>\n<!-- /wp:paragraph -->"


def _h(text, level=2):
    return f'<!-- wp:heading {{"level":{level}}} -->\n<h{level} class="wp-block-heading">{escape(text)}</h{level}>\n<!-- /wp:heading -->'


def _list(items):
    lis = "".join(f'<!-- wp:list-item -->\n<li>{i}</li>\n<!-- /wp:list-item -->' for i in items)
    return f"<!-- wp:list -->\n<ul class=\"wp-block-list\">{lis}</ul>\n<!-- /wp:list -->"


def _quote(lines_html):
    body = "<br>".join(lines_html)
    return ('<!-- wp:quote {"className":"is-style-plain"} -->\n'
            '<blockquote class="wp-block-quote is-style-plain"><!-- wp:paragraph {"align":"center"} -->\n'
            f'<p class="has-text-align-center">{body}</p>\n<!-- /wp:paragraph --></blockquote>\n<!-- /wp:quote -->')


def _tag(word):
    return re.sub(r"[\s#·,./]+", "", str(word))


def _img(im):
    if not im:
        return ""
    idattr = f' class="wp-image-{im["id"]}"' if im.get("id") else ""
    attrs = f'{{"id":{im["id"]},"sizeSlug":"large","linkDestination":"none"}}' if im.get("id") else '{"sizeSlug":"large","linkDestination":"none"}'
    cap = f'<figcaption class="wp-element-caption">{escape(im["caption"])}</figcaption>' if im.get("caption") else ""
    return (f'<!-- wp:image {attrs} -->\n<figure class="wp-block-image size-large"><img src="{escape(im["url"])}" '
            f'alt="{escape(im.get("alt", ""))}"{idattr}/>{cap}</figure>\n<!-- /wp:image -->')


def _button(label, url, outline=False):
    attrs = ' {"className":"is-style-outline"}' if outline else ""
    cls = " is-style-outline" if outline else ""
    return (f'<!-- wp:button{attrs} -->\n<div class="wp-block-button{cls}"><a class="wp-block-button__link wp-element-button" '
            f'href="{escape(url)}">{escape(label)}</a></div>\n<!-- /wp:button -->')


def _card(topic):
    """apuda.app 소개 카드: 제목 링크 + 설명 + 바로가기 버튼 3개 (모두 클릭 시 사이트 이동)."""
    title = (f'<!-- wp:paragraph {{"fontSize":"large"}} -->\n<p class="has-large-font-size"><strong>'
             f'<a href="{SITE}">아프다 ApuDa | 암 정보와 환자·보호자 길잡이</a></strong></p>\n<!-- /wp:paragraph -->')
    desc = _p("아프지만, 다행이다. 암 진단 첫 30일 안내서·FAQ·환자 카페·패밀리 서비스를 한곳에서 볼 수 있습니다.")
    buttons = ("<!-- wp:buttons -->\n<div class=\"wp-block-buttons\">"
               + _button("apuda.app 바로가기", SITE)
               + _button(f"{topic.cancer_name} {topic.title.split('·')[0]} FAQ {len(topic.items)}문항", topic.page_url, True)
               + _button(f"{topic.cancer_name} FAQ 100문항", topic.hub_url, True)
               + "</div>\n<!-- /wp:buttons -->")
    return ('<!-- wp:group {"style":{"color":{"background":"#f3f6fb"}},"layout":{"type":"constrained"}} -->\n'
            '<div class="wp-block-group has-background" style="background-color:#f3f6fb">'
            + "\n" + title + "\n" + desc + "\n" + buttons + "\n</div>\n<!-- /wp:group -->")


def _notice(topic):
    """안내문 + 접히는 참고자료 목록."""
    lines = escape(NOTICE) + "<br>" + escape(REVIEW.format(updated=topic.updated or "미확인"))
    out = [f'<!-- wp:paragraph {{"fontSize":"small"}} -->\n<p class="has-small-font-size">{lines}</p>\n<!-- /wp:paragraph -->']
    sources = topic.source_list()
    if sources:
        items = []
        for src in sources:
            org = src.get("organization") or ""
            label = src["title"] if not org or src["title"].startswith(org) else f"{org} · {src['title']}"
            items.append(f'<a href="{escape(src["url"])}" target="_blank" rel="nofollow noopener noreferrer">{escape(label)}</a>')
        out.append('<!-- wp:details {"fontSize":"small"} -->\n<details class="wp-block-details has-small-font-size">'
                   f'<summary>참고자료 {len(sources)}건 펼쳐 보기</summary>' + _list(items) + '</details>\n<!-- /wp:details -->')
    return "\n\n".join(out)


def hashtags(draft, topic):
    words = [topic.cancer_name] + list(draft.get("hashtags") or []) + ["아프다", "APUDA"]
    out, seen = [], set()
    for w in words:
        t = _tag(w)
        if t and t not in seen:
            seen.add(t)
            out.append(t)
    return out[:14]


def render(draft, topic, images=None):
    images = images or {}
    out = []
    if images.get("cover") and images["cover"].get("inline"):
        out.append(_img(images["cover"]))
    out += [_p(f"ApuDa {topic.cancer_name}, {topic.title}", cls="has-small-font-size")]

    rq = [q for q in (draft.get("reader_questions") or []) if q][:3]
    if rq:
        out.append(_quote([escape("“" + q.strip("“”\" ") + "”") for q in rq]))
    for para in draft.get("intro") or [draft.get("excerpt", "")]:
        if para:
            out.append(_p(para))

    if images.get("flow"):
        out.append(_img(images["flow"]))

    n = 0
    for section in draft["sections"]:
        n += 1
        out.append(_h(f"{n}. {section['heading']}"))
        bullets = [p for p in section["paragraphs"] if p.startswith("• ")]
        prose = [p for p in section["paragraphs"] if not p.startswith("• ")]
        out.extend(_p(p) for p in prose)
        if bullets:
            out.append(_list([escape(b[2:]) for b in bullets]))

    qs = [q for q in (draft.get("questions_for_visit") or []) if q][:len(CIRCLED)]
    if qs:
        n += 1
        out.append(_h(f"{n}. 진료실에서 확인할 질문"))
        out.append(_p("<br>".join(f"{CIRCLED[i]} {escape(q)}" for i, q in enumerate(qs)), raw=True))
        if images.get("questions"):
            out.append(_img(images["questions"]))

    if draft.get("key_message"):
        out.append(_h("이번 글의 핵심 메시지", 3))
        msg = draft["key_message"]
        for para in (msg if isinstance(msg, list) else [msg]):
            out.append(_p(para))

    out.append("<!-- wp:separator -->\n<hr class=\"wp-block-separator has-alpha-channel-opacity\"/>\n<!-- /wp:separator -->")
    out.append(_quote([
        "<em>ApuDa | 아프지만, 다행이다.</em>",
        escape(f"{topic.cancer_name}{_eul(topic.cancer_name)} 비롯한 다양한 암종의 환자교육 자료와"),
        "최신 암 관련 뉴스를 확인하세요.",
    ]))
    out.append(_card(topic))
    out.append(_notice(topic))
    tags = " ".join(f'<a href="{SITE}">#{escape(t)}</a>' if t in ("아프다", "APUDA") else "#" + escape(t)
                    for t in hashtags(draft, topic))
    out.append(_p(tags, raw=True))
    return "\n\n".join(out)
