"""Post to WordPress through the REST API with an Application Password.

Always creates or updates a DRAFT. Publishing stays a human click in wp-admin.
"""
import base64
import json
import urllib.parse
import urllib.request


class WordPress:
    def __init__(self, site_url, user, app_password):
        self.base = site_url.rstrip("/") + "/wp-json/wp/v2"
        token = base64.b64encode(f"{user}:{app_password.replace(' ', '')}".encode()).decode()
        self.headers = {"Authorization": "Basic " + token, "Content-Type": "application/json; charset=utf-8"}

    def _call(self, method, path, body=None, query=None):
        url = self.base + path + ("?" + urllib.parse.urlencode(query) if query else "")
        data = json.dumps(body).encode("utf-8") if body is not None else None
        req = urllib.request.Request(url, data=data, method=method, headers=self.headers)
        with urllib.request.urlopen(req, timeout=60) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def _term(self, kind, name):
        found = self._call("GET", f"/{kind}", query={"search": name, "per_page": 20})
        for term in found:
            if term["name"] == name:
                return term["id"]
        return self._call("POST", f"/{kind}", {"name": name})["id"]

    def find_by_slug(self, slug):
        posts = self._call("GET", "/posts", query={"slug": slug, "status": "draft,pending,publish,private", "context": "edit"})
        return posts[0] if posts else None

    def upsert_draft(self, slug, title, content, excerpt, category, tags):
        payload = {
            "slug": slug, "title": title, "content": content, "excerpt": excerpt,
            "categories": [self._term("categories", category)],
            "tags": [self._term("tags", t) for t in tags],
            "comment_status": "closed", "ping_status": "closed",
        }
        existing = self.find_by_slug(slug)
        if existing:
            if existing["status"] == "publish":
                raise RuntimeError(f"이미 공개된 글은 덮어쓰지 않음: {existing['link']}")
            return self._call("POST", f"/posts/{existing['id']}", payload), "updated"
        payload["status"] = "draft"
        return self._call("POST", "/posts", payload), "created"
