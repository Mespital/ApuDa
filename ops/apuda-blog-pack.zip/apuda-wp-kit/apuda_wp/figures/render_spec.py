"""앱 spec(JSON) → Pillow 300dpi PNG. 앱의 SVG 템플릿과 동일 레이아웃."""
from .apuda_render import *

def _footbox(c, y, maxw, text, tone, PAD):
    m={'tint':(TINT,BLUE),'gold':(LGOLD,(153,107,5)),'red':(REDT,ORANGE)}
    bg,fg=m.get(tone,m['tint'])
    fl=c.wrap(text,'Medium',13,maxw-32); fh=24+len(fl)*20
    c.rect(PAD,y,maxw,fh,fill=bg,radius=8)
    yy=y+12
    for ln in fl: c.text(PAD+16,yy,ln,'Medium',13,fg); yy+=20
    return y+fh

def render_columns(spec, path):
    W=880; PAD=40; maxw=W-PAD*2
    c=Canvas(W,700)
    y=c.title(PAD,34,spec['title'],maxw); y+=22
    if spec.get('subtitle'): y=c.para(PAD,y,spec['subtitle'],'Medium',14,INK,maxw,1.5); y+=16
    cols=spec['columns']; n=len(cols); gap=16
    cw=(maxw-gap*(n-1))/n; top=y
    tone={'confirm':(BLUE,LBLUE),'progress':((153,107,5),LGOLD),'pending':(GRAY_S,LGRAY),'neutral':(BLUE,LBLUE)}
    cache=[]; maxh=0
    for col in cols:
        acc,bg=tone.get(col.get('tone','neutral'))
        inner=cw-36
        heads=c.wrap(col['heading'],'Bold',16,inner)
        headh=16+(24 if col.get('tag') else 0)+6+len(heads)*22+14
        items=[c.wrap(it,'Regular',13.5,inner-14) for it in col['items']]
        bodyh=14
        for it in items: bodyh+=max(len(it)*20,20)+9
        bodyh+=16-9
        total=headh+bodyh; maxh=max(maxh,total)
        cache.append((acc,bg,heads,items,headh))
    for i,col in enumerate(cols):
        x=PAD+i*(cw+gap); acc,bg,heads,items,headh=cache[i]
        c.rect(x,top,cw,maxh,fill=WHITE,radius=12,outline=acc,width=1.5)
        c.rect(x,top,cw,headh,fill=bg,radius=12)
        c.rect(x,top+headh-12,cw,12,fill=bg)
        ty=top+16
        if col.get('tag'):
            bw,_=c.measure(col['tag'],'Bold',12)
            c.rect(x+18,ty,bw+18,22,fill=acc,radius=11)
            c.text(x+18+9,ty+4,col['tag'],'Bold',12,WHITE); ty+=30
        for ln in heads: c.text(x+18,ty,ln,'Bold',16,acc); ty+=22
        by=top+headh+14
        for it in items:
            c.ellipse(x+18,by+6,6,6,fill=acc)
            yy=by
            for ln in it: c.text(x+18+14,yy,ln,'Regular',13.5,INK); yy+=20
            by+=max(len(it)*20,20)+9
    y=top+maxh+18
    if spec.get('footer'): y=_footbox(c,y,maxw,spec['footer'],spec.get('footerTone','tint'),PAD)
    y+=16; c.signature(W-PAD,y); y+=24
    c.img.crop((0,0,W*SCALE,int((y+PAD-16)*SCALE))).save(path)

def render_myth_fact(spec, path):
    W=880; PAD=40; maxw=W-PAD*2
    c=Canvas(W,700)
    y=c.title(PAD,34,spec['title'],maxw); y+=22
    if spec.get('subtitle'): y=c.para(PAD,y,spec['subtitle'],'Medium',14,INK,maxw,1.5); y+=16
    for p in spec['pairs']:
        inner=maxw-40
        wl=c.wrap(p['myth'],'Medium',14,inner); rl=c.wrap(p['fact'],'Regular',13.5,inner)
        ch=14+max(len(wl)*20,20)+8+max(len(rl)*20,20)+14
        c.rect(PAD,y,maxw,ch,fill=WHITE,radius=10,outline=(230,230,230),width=1.5)
        cy=y+14
        c.ellipse(PAD+18,cy+1,20,20,fill=GRAY_S)
        c.text(PAD+18+10,cy+11,'×','Bold',14,WHITE,anchor='mm')
        yy=cy
        for ln in wl: c.text(PAD+18+30,yy,ln,'Medium',14,(110,110,110)); yy+=20
        cy=yy+8
        c.ellipse(PAD+18,cy+1,20,20,fill=BLUE)
        c.text(PAD+18+10,cy+11,'O','Bold',13,WHITE,anchor='mm')
        yy=cy
        for ln in rl: c.text(PAD+18+30,yy,ln,'Regular',13.5,INK); yy+=20
        y+=ch+12
    if spec.get('footer'): y=_footbox(c,y,maxw,spec['footer'],spec.get('footerTone','tint'),PAD)
    y+=16; c.signature(W-PAD,y); y+=24
    c.img.crop((0,0,W*SCALE,int((y+PAD-16)*SCALE))).save(path)

def render_checklist(spec, path):
    narrow=spec.get('narrow',True)
    W=756 if narrow else 880; PAD=40; maxw=W-PAD*2
    c=Canvas(W,700)
    alert=spec.get('alert',False)
    if alert:
        c.rect(PAD,34,maxw,52,fill=ORANGE,radius=10)
        c.text(PAD+18,34+15,spec['title'],'Bold',18,WHITE)
        y=34+52+16
        if spec.get('subtitle'): y=c.para(PAD,y,spec['subtitle'],'Medium',13.5,INK,maxw,1.5); y+=14
    else:
        y=c.title(PAD,34,spec['title'],maxw); y+=20
        if spec.get('subtitle'): y=c.para(PAD,y,spec['subtitle'],'Medium',13.5,GRAY,maxw,1.5); y+=16
    acc=ORANGE if alert else BLUE; bg=REDT if alert else TINT
    inner=maxw-30
    items=[c.wrap(it,'Medium',14.5,inner-30) for it in spec['items']]
    listh=16
    for it in items: listh+=max(len(it)*21,21)+11
    listh+=16-11
    c.rect(PAD,y,maxw,listh,fill=bg,radius=10)
    by=y+16
    for it in items:
        c.rect(PAD+18,by+2,16,16,fill=WHITE,radius=3,outline=acc,width=2)
        yy=by
        for ln in it: c.text(PAD+18+26,yy,ln,'Medium',14.5,INK); yy+=21
        by+=max(len(it)*21,21)+11
    y+=listh+16
    if spec.get('footer'): y=_footbox(c,y,maxw,spec['footer'],spec.get('footerTone','gold' if not alert else 'tint'),PAD)
    y+=16; c.signature(W-PAD,y); y+=24
    c.img.crop((0,0,W*SCALE,int((y+PAD-16)*SCALE))).save(path)

RENDER={'columns':render_columns,'myth_fact':render_myth_fact,'checklist':render_checklist}

def render_steps(spec, path):
    W=880; PAD=40; maxw=W-PAD*2
    c=Canvas(W,760)
    y=c.title(PAD,34,spec['title'],maxw); y+=18
    if spec.get('subtitle'): y=c.para(PAD,y,spec['subtitle'],'Medium',14,INK,maxw,1.5); y+=10
    if spec.get('badge'):
        bw,_=c.measure(spec['badge'],'Bold',13)
        c.rect(PAD,y,bw+28,26,fill=GOLD,radius=999)
        c.text(PAD+14,y+6,spec['badge'],'Bold',13,INK); y+=38
    steps=spec['steps']
    for i,st in enumerate(steps):
        headL=c.wrap(st['head'],'Bold',16.5,maxw-72)
        subL=c.wrap(st['sub'],'Regular',13.5,maxw-72) if st.get('sub') else []
        rowH=max(40,len(headL)*22+len(subL)*20)+14
        c.ellipse(PAD,y,40,40,fill=BLUE)
        c.text(PAD+20,y+20,str(i+1),'Bold',18,WHITE,anchor='mm')
        if i<len(steps)-1:
            c.rect(PAD+19,y+40,2.5,rowH-34,fill=BLUE)
        ty=y+2
        for ln in headL: c.text(PAD+56,ty,ln,'Bold',16.5,INK); ty+=22
        for ln in subL: c.text(PAD+56,ty,ln,'Regular',13.5,(89,89,89)); ty+=20
        y+=rowH
    y+=6
    if spec.get('footer'): y=_footbox(c,y,maxw,spec['footer'],spec.get('footerTone','tint'),PAD)
    y+=16; c.signature(W-PAD,y); y+=24
    c.img.crop((0,0,W*SCALE,int((y+PAD-16)*SCALE))).save(path)

RENDER['steps']=render_steps

def render_reftable(spec, path):
    """표적별 요약 참조표: 각 행 = 라벨칩 + 제목 + 핵심 포인트."""
    W=880; PAD=40; maxw=W-PAD*2
    c=Canvas(W,900)
    y=c.title(PAD,34,spec['title'],maxw); y+=20
    if spec.get('subtitle'): y=c.para(PAD,y,spec['subtitle'],'Medium',14,INK,maxw,1.5); y+=16
    for row in spec['rows']:
        label=row['label']; head=row['head']; note=row['note']
        inner=maxw-200
        nl=c.wrap(note,'Regular',13,inner)
        rh=max(48, len(nl)*19+22)
        c.rect(PAD,y,maxw,rh,fill=TINT,radius=10)
        # 라벨 칩 (파랑)
        c.rect(PAD+14,y+13,84,rh-26 if rh-26>22 else 22,fill=BLUE,radius=7)
        c.text(PAD+14+42,y+rh/2,label,'Bold',14,WHITE,anchor='mm')
        # 제목
        c.text(PAD+112,y+13,head,'Bold',14.5,INK)
        # 핵심 포인트
        ny=y+13+21
        for ln in nl:
            c.text(PAD+112,ny,ln,'Regular',13,GRAY); ny+=19
        y+=rh+10
    y+=6
    if spec.get('footer'): y=_footbox(c,y,maxw,spec['footer'],spec.get('footerTone','gold'),PAD)
    y+=16; c.signature(W-PAD,y); y+=24
    c.img.crop((0,0,W*SCALE,int((y+PAD-16)*SCALE))).save(path)

RENDER['reftable']=render_reftable

def render_form(spec, path):
    W=756; PAD=40; maxw=W-PAD*2
    c=Canvas(W,700)
    y=c.title(PAD,34,spec['title'],maxw); y+=20
    if spec.get('subtitle'): y=c.para(PAD,y,spec['subtitle'],'Medium',13.5,GRAY,maxw,1.5); y+=16
    for label in spec['fields']:
        # 라벨 길면 기입줄 아래로 더 확보
        fh=14+22+18+14
        c.rect(PAD,y,maxw,fh,fill=WHITE,radius=10,outline=LINE,width=1.5)
        c.rect(PAD+18,y+16,5,18,fill=BLUE,radius=3)
        c.text(PAD+18+13,y+16,label,'Bold',15.5,BLUE)
        ly=y+16+26+8
        c.line(PAD+18,ly,W-PAD-18,ly,fill=LINE,width=1.2,dash=(6,5))
        y+=fh+12
    c.text(PAD,y+4,'작성일','Medium',13,GRAY)
    lw,_=c.measure('작성일','Medium',13)
    c.line(PAD+lw+12,y+18,PAD+lw+12+180,y+18,fill=LINE,width=1.2,dash=(6,5))
    y+=34; c.signature(W-PAD,y); y+=24
    c.img.crop((0,0,W*SCALE,int((y+PAD-16)*SCALE))).save(path)

RENDER['form']=render_form
