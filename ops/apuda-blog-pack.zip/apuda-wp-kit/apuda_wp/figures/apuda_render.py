"""ApuDa 책 도판 렌더러 — Pillow 기반. 브랜드 스타일·상태 3색·우하단 서명 내장."""
from PIL import Image, ImageDraw, ImageFont

# 브랜드 컬러
BLUE   = (11, 95, 165)      # #0B5FA5 딥블루 (확정/사실)
GOLD   = (245, 179, 1)      # #F5B301 웜골드 (진행 중)
GRAY_S = (140, 140, 140)    # 예정/미확인 (중립 회색)
INK    = (51, 51, 51)       # 본문
GRAY   = (115, 115, 115)    # 보조 텍스트
TINT   = (240, 246, 251)    # 옅은 블루 배경
LBLUE  = (229, 238, 248)
LGOLD  = (254, 246, 224)
LGRAY  = (241, 243, 245)
WHITE  = (255, 255, 255)
ORANGE = (224, 118, 46)     # 주의/안전
REDT   = (250, 237, 230)
LINE   = (184, 199, 219)

SCALE = 3  # 3x → 300dpi 상당 (본문 판면 128mm 기준)

import glob as _glob
_FONT_DIRS = ['/usr/share/fonts/opentype/noto', '/usr/share/fonts/noto-cjk', '/usr/share/fonts/google-noto-cjk',
              '/usr/share/fonts/truetype/noto', '/usr/local/share/fonts']
def _find_font(weight):
    for d in _FONT_DIRS:
        hits = sorted(_glob.glob(f"{d}/**/NotoSansCJK*-{weight}.tt[cf]", recursive=True)) + \
               sorted(_glob.glob(f"{d}/**/NotoSansKR*-{weight}.[ot]tf", recursive=True))
        if hits:
            return hits[0]
    raise FileNotFoundError("Noto Sans CJK 폰트 없음: sudo apt install -y fonts-noto-cjk")
_FONTS = {w: None for w in ('Black', 'Bold', 'Medium', 'Regular')}
_cache = {}
_KR_INDEX = 1  # Noto Sans CJK .ttc: 0=JP, 1=KR
def font(style, size):
    key = (style, int(size*SCALE))
    if key not in _cache:
        # NotoSansCJK ttc: KR은 index 존재. Bold.ttc 등은 weight별 분리 파일이라 index 0 사용
        _FONTS[style] = _FONTS[style] or _find_font(style)
        _cache[key] = ImageFont.truetype(_FONTS[style], int(size*SCALE), index=_KR_INDEX if _FONTS[style].endswith('.ttc') else 0)
    return _cache[key]

class Canvas:
    def __init__(self, w, h, bg=WHITE):
        self.w, self.h = w, h
        self.img = Image.new('RGB', (int(w*SCALE), int(h*SCALE)), bg)
        self.d = ImageDraw.Draw(self.img)

    def rect(self, x, y, w, h, fill=None, radius=0, outline=None, width=1):
        box = [x*SCALE, y*SCALE, (x+w)*SCALE, (y+h)*SCALE]
        if radius:
            self.d.rounded_rectangle(box, radius=radius*SCALE, fill=fill,
                                     outline=outline, width=int(width*SCALE))
        else:
            self.d.rectangle(box, fill=fill, outline=outline, width=int(width*SCALE))

    def ellipse(self, x, y, w, h, fill=None):
        self.d.ellipse([x*SCALE, y*SCALE, (x+w)*SCALE, (y+h)*SCALE], fill=fill)

    def line(self, x1, y1, x2, y2, fill=LINE, width=1, dash=None):
        if dash:
            # 점선
            import math
            dx, dy = x2-x1, y2-y1
            dist = math.hypot(dx, dy)
            if dist == 0: return
            ux, uy = dx/dist, dy/dist
            on, off = dash
            pos = 0
            while pos < dist:
                seg = min(on, dist-pos)
                sx, sy = x1+ux*pos, y1+uy*pos
                ex, ey = x1+ux*(pos+seg), y1+uy*(pos+seg)
                self.d.line([sx*SCALE, sy*SCALE, ex*SCALE, ey*SCALE], fill=fill, width=int(width*SCALE))
                pos += on+off
        else:
            self.d.line([x1*SCALE, y1*SCALE, x2*SCALE, y2*SCALE], fill=fill, width=int(width*SCALE))

    def text(self, x, y, s, style='Regular', size=14, fill=INK, anchor='la'):
        self.d.text((x*SCALE, y*SCALE), s, font=font(style, size), fill=fill, anchor=anchor)

    def measure(self, s, style, size):
        f = font(style, size)
        bbox = self.d.textbbox((0,0), s, font=f)
        return (bbox[2]-bbox[0])/SCALE, (bbox[3]-bbox[1])/SCALE

    def wrap(self, s, style, size, max_w):
        """글자 단위 줄바꿈 (한글은 어절+글자 혼합)."""
        f = font(style, size)
        lines, cur = [], ''
        for ch in s:
            test = cur+ch
            w = self.d.textlength(test, font=f)/SCALE
            if w > max_w and cur:
                lines.append(cur); cur = ch
            else:
                cur = test
        if cur: lines.append(cur)
        return lines

    def para(self, x, y, s, style, size, fill, max_w, lh=1.5):
        """자동 줄바꿈 문단. 반환: 다음 y."""
        lines = self.wrap(s, style, size, max_w)
        step = size*lh
        for ln in lines:
            self.text(x, y, ln, style, size, fill)
            y += step
        return y

    def signature(self, right_x, bottom_y):
        """우하단 브랜드 서명. right_x=오른쪽 끝, bottom_y=베이스라인 기준 하단."""
        tag = '아프지만, 다행이다'
        wt, _ = self.measure(tag, 'Medium', 15)
        wa, _ = self.measure('ApuDa', 'Bold', 15)
        gap = 6
        total = wa + gap + wt
        x = right_x - total
        self.text(x, bottom_y, 'ApuDa', 'Bold', 15, BLUE)
        self.text(x+wa+gap, bottom_y, tag, 'Medium', 15, BLUE)

    def title(self, x, y, s, max_w):
        """제목 + 골드 언더바. 반환: 다음 y."""
        y = self.para(x, y, s, 'Bold', 26, BLUE, max_w, 1.35)
        y += 6
        self.rect(x, y, 48, 4, fill=GOLD, radius=2)
        return y + 4

    def save(self, path):
        self.img.save(path, 'PNG')
