# 아프다 워드프레스 자동 글쓰기 키트

apuda.app의 FAQ 주제 묶음 하나를 블로그 글 하나로 바꿔 **워드프레스 초안**으로 올린다.
공개 버튼은 사람이 누른다. 텔레그램으로 검토 링크가 온다.

```
아프다 레포 FAQ (검토된 원문)
  → Claude API가 글로 다시 씀 (원문 밖 사실 금지)
  → 검사 (원문에 없는 숫자, 금지 표현, 분량)
  → 프로그램이 링크·출처·안내문을 붙임
  → 워드프레스 초안 + 텔레그램 알림
```

외부 라이브러리 없이 파이썬 3 기본 모듈만 쓴다.

## 1. 워드프레스 사이트 만들기 (한 번만)

권장: **blog.apuda.app**. 호스팅어에서 워드프레스 1클릭 설치 → 하위 도메인 연결.

1. 호스팅어 hPanel → 웹사이트 → 워드프레스 설치, 도메인은 `blog.apuda.app`
2. 도메인 DNS에 hPanel이 알려주는 레코드 추가 (apuda.app DNS를 관리하는 곳에서)
3. 워드프레스 관리자 → 설정 → 고유주소 → **글 이름** 선택 (REST API가 깔끔해진다)
4. 사용자 → 새로 추가 → 아이디 `apuda-bot`, 역할 **편집자**
5. 그 계정으로 로그인 → 프로필 → **응용 프로그램 비밀번호** → 이름 `apuda-wp-kit` → 발급된 값 복사
6. 브라우저에서 `https://blog.apuda.app/wp-json/wp/v2/posts` 가 JSON으로 열리는지 확인
   - 404면 보안 플러그인이 REST를 막은 것
   - 키트 실행 시 401이면 서버가 Authorization 헤더를 안 넘기는 것. Nginx면 `fastcgi_param HTTP_AUTHORIZATION $http_authorization;`

SEO 플러그인(Rank Math 또는 Yoast)을 깔고, 그 플러그인의 사이트맵을 서치콘솔·서치어드바이저에 따로 제출한다.

## 2. VPS에 설치

```bash
cd /home/apuda
git clone https://github.com/Mespital/ApuDa.git      # 이미 있으면 생략
cd apuda-wp-kit   # 설치팩을 /home/apuda 에 풀었으면 이미 있음
cp .env.example .env && chmod 600 .env && nano .env   # 값 채우기
```

API 키와 응용 프로그램 비밀번호는 `.env`에만 넣는다. 채팅에 붙여넣지 않는다.

## 3. 써 보기

```bash
python3 run.py list                         # 주제 목록, ✓ = 올린 것
python3 run.py preview bladder/bcg          # API 없이 미리보기 HTML (previews/)
python3 run.py preview bladder/bcg --claude # Claude로 쓴 글 미리보기, 검사 결과 표시
python3 run.py post bladder/bcg             # 워드프레스 초안으로 올리기
python3 run.py next                         # 아직 안 올린 다음 주제 하나
```

`--outline`을 붙이면 Claude API 없이 "요약 + 질문 목록 + 아프다 링크" 형태의 짧은 글로 올린다.

## 4. 자동 실행 (원할 때만)

기존 크론은 건드리지 않는다. 이 줄은 **직접** 추가한다. 예: 매주 화요일 10:00 KST

```
0 1 * * 2 /home/apuda/apuda-wp-kit/run_weekly.sh >> /home/apuda/apuda-wp-kit/cron.log 2>&1
```

## 5. 안전장치

- **초안만 만든다.** 이미 공개된 글은 덮어쓰지 않는다. 같은 주제를 다시 돌리면 초안을 갱신한다.
- **검사에 걸리면 올리지 않는다.** FAQ 원문에 없는 숫자, `완치·보장·100%·부작용 없음` 등 금지 표현, 너무 짧은 글.
- **링크·출처·안내문은 프로그램이 붙인다.** 모델이 출처를 지어낼 수 없다. 출처는 FAQ에 달린 링크 그대로다.
- **안내문**: "문항별 전문의 검토는 완료되지 않았으며 진단·처방을 대신하지 않는다"가 모든 글 끝에 들어간다.
- 댓글·핑백은 닫힌 상태로 만든다.

## 6. 공개 전에 사람이 볼 것

- 원문 FAQ와 의미가 같은지 (검사는 숫자와 표현만 본다. 의미 왜곡은 사람이 잡아야 한다)
- 제목이 겁주는 문구가 아닌지
- 아프다 주제 쪽 링크가 맞게 열리는지

## 7. 주제 늘리기

글감은 레포의 `public-site/scripts/faq-topics/*.json` 이다. 지금은 방광암 9개뿐이다.
apuda.app에 다른 암종의 주제 쪽이 생기면 이 키트는 자동으로 그 주제도 글감으로 쓴다.
