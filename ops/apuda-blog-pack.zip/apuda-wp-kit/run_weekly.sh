#!/usr/bin/env bash
# 주 1회: 아프다 레포를 최신으로 받고, 아직 안 올린 주제 하나를 워드프레스 '초안'으로 올린다.
# 공개는 사람이 wp-admin에서 누른다.
set -euo pipefail
cd "$(dirname "$0")"
APUDA_REPO=$(grep "^APUDA_REPO=" .env | cut -d= -f2-)
git -C "$APUDA_REPO" pull -q --ff-only
python3 run.py next
