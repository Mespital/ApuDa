#!/usr/bin/env python3
"""ApuDa FAQ topic -> WordPress draft.

  python3 run.py list                       # topics and whether each was posted
  python3 run.py preview bladder/bcg        # write preview HTML only (no API, no WordPress)
  python3 run.py preview bladder/bcg --claude   # same, but draft with Claude API
  python3 run.py next                       # draft the next unposted topic and post it as a WP draft
  python3 run.py post bladder/bcg           # draft one topic and post it as a WP draft

Settings come from .env next to this file (see .env.example).
"""
import argparse
import datetime as dt
import json
import os
import sys
import urllib.parse
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from apuda_wp import draft as drafting, guard, render  # noqa: E402
from apuda_wp import images as imaging  # noqa: E402
from apuda_wp.source import load_topics  # noqa: E402
from apuda_wp.wordpress import WordPress  # noqa: E402

LOG = HERE / "posted.json"
OUT = HERE / "previews"


def load_env():
    env_file = HERE / ".env"
    if env_file.exists():
        for line in env_file.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


def telegram(text):
    token, chat = os.environ.get("TELEGRAM_BOT_TOKEN"), os.environ.get("TELEGRAM_CHAT_ID")
    if not token or not chat:
        return
    data = urllib.parse.urlencode({"chat_id": chat, "text": text, "disable_web_page_preview": "true"}).encode()
    try:
        urllib.request.urlopen(f"https://api.telegram.org/bot{token}/sendMessage", data=data, timeout=20)
    except Exception as exc:  # noqa: BLE001
        print("telegram failed:", exc, file=sys.stderr)


def posted():
    return json.loads(LOG.read_text(encoding="utf-8")) if LOG.exists() else {}


def build(topic, use_claude):
    draft = drafting.draft_with_ai(topic) if use_claude else drafting.draft_outline(topic)
    problems = guard.check(draft, topic)
    return draft, problems


def save_preview(topic, draft, html, problems):
    OUT.mkdir(exist_ok=True)
    path = OUT / f"{topic.cancer_slug}-{topic.topic_slug}.html"
    banner = ("<p style='background:#fde8e8;padding:8px'>검사 실패: " + " / ".join(problems) + "</p>") if problems else ""
    path.write_text(f"<!doctype html><meta charset='utf-8'><title>{draft['title']}</title>"
                    f"<body style='max-width:720px;margin:24px auto;font-family:sans-serif;line-height:1.7'>"
                    f"{banner}<h1>{draft['title']}</h1>{html}</body>", encoding="utf-8")
    return path


def build_images(draft, topic, upload=None):
    """Make figures; upload them if a WordPress client is given. Never fails the post."""
    if os.environ.get("IMAGES", "1") == "0":
        return {}, []
    try:
        figs, notes = imaging.make_images(draft, topic, OUT / "img")
    except Exception as exc:  # noqa: BLE001
        return {}, [f"이미지 건너뜀({type(exc).__name__}: {exc}) — sudo apt install -y python3-pil fonts-noto-cjk 확인"]
    images = {}
    for fig in figs:
        if upload:
            try:
                fig.update(upload(fig["path"], fig["alt"], fig["caption"]))
            except Exception as exc:  # noqa: BLE001
                notes.append(f"{fig['role']} 업로드 실패: {exc}")
                continue
        else:
            fig["url"] = "img/" + Path(fig["path"]).name
            fig["inline"] = True
        if fig["role"] == "cover" and os.environ.get("COVER_IN_BODY") == "1":
            fig["inline"] = True
        images[fig["role"]] = fig
    return images, notes


def ai_draft_blocked(topic):
    if topic.ai_draft and os.environ.get("ALLOW_AI_DRAFT_FAQ") != "1":
        print(f"건너뜀: {topic.key} 는 FAQ 원문이 아직 AI 확장 초안 상태(전문의 검토·국내 기준 확인 전). "
              "올리려면 ALLOW_AI_DRAFT_FAQ=1")
        return True
    return False


def post(topic, use_claude):
    if ai_draft_blocked(topic):
        return 0
    draft, problems = build(topic, use_claude)
    html = render.render(draft, topic)
    preview = save_preview(topic, draft, html, problems)
    if problems:
        msg = f"[아프다 WP] 검사 실패, 올리지 않음: {topic.key}\n- " + "\n- ".join(problems)
        print(msg)
        telegram(msg)
        return 1
    wp = WordPress(os.environ["WP_SITE_URL"], os.environ["WP_USER"], os.environ["WP_APP_PASSWORD"])
    images, notes = build_images(draft, topic, upload=wp.upload_media)
    for note in notes:
        print("주의:", note)
    html = render.render(draft, topic, images)
    slug = f"{topic.cancer_slug}-{topic.topic_slug}"
    result, action = wp.upsert_draft(
        slug=slug, title=draft["title"], content=html, excerpt=draft.get("excerpt", ""),
        category=os.environ.get("WP_CATEGORY", "암 정보"),
        tags=render.hashtags(draft, topic)[:10],
        featured_media=(images.get("cover") or {}).get("id"))
    log = posted()
    log[topic.key] = {"post_id": result["id"], "status": result["status"], "at": dt.datetime.now().isoformat(timespec="seconds")}
    LOG.write_text(json.dumps(log, ensure_ascii=False, indent=2), encoding="utf-8")
    edit = os.environ["WP_SITE_URL"].rstrip("/") + f"/wp-admin/post.php?post={result['id']}&action=edit"
    msg = f"[아프다 WP] 초안 {action}: {draft['title']} (이미지 {len(images)}장)\n검토 후 공개: {edit}"
    if notes:
        msg += "\n주의: " + " / ".join(notes)
    print(msg, "| preview:", preview)
    telegram(msg)
    return 0


def main():
    load_env()
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["list", "preview", "next", "post"])
    ap.add_argument("topic", nargs="?")
    ap.add_argument("--claude", "--ai", dest="claude", action="store_true", help="preview with AI drafting (Claude or Gemini)")
    ap.add_argument("--outline", action="store_true", help="post/next without Claude API (outline post)")
    args = ap.parse_args()

    topics = load_topics(Path(os.environ.get("APUDA_REPO", HERE.parent / "ApuDa")))
    by_key = {t.key: t for t in topics}
    done = posted()

    if args.cmd == "list":
        for t in topics:
            mark = "✓ " if t.key in done else ("· " if t.ai_draft else "  ")
            print(mark + f"{t.key}  ({len(t.items)}문항)  {t.cancer_name} {t.title}" + ("  [AI 초안 FAQ, 기본 제외]" if t.ai_draft else ""))
        return 0
    if args.cmd == "next":
        allow = os.environ.get("ALLOW_AI_DRAFT_FAQ") == "1"
        pending = [t for t in topics if t.key not in done and (allow or not t.ai_draft)]
        if not pending:
            print("올릴 주제가 없음")
            return 0
        return post(pending[0], use_claude=not args.outline)
    topic = by_key.get(args.topic or "")
    if not topic:
        print("주제를 찾을 수 없음. run.py list 로 확인:", args.topic)
        return 2
    if args.cmd == "preview":
        draft, problems = build(topic, args.claude)
        images, notes = build_images(draft, topic) if not problems else ({}, [])
        for note in notes:
            print("주의:", note)
        path = save_preview(topic, draft, render.render(draft, topic, images), problems)
        print("preview:", path, "| 검사:", "통과" if not problems else problems)
        return 0 if not problems else 1
    return post(topic, use_claude=not args.outline)


def safe_main():
    try:
        return main()
    except Exception as exc:  # noqa: BLE001
        msg = f"[아프다 WP] 실행 실패: {type(exc).__name__}: {exc}"
        url = getattr(exc, "url", "") or ""
        if "401" in str(exc) and "anthropic.com" in url:
            msg += "\n→ Claude API 키(ANTHROPIC_API_KEY)가 비었거나 무효"
        elif "googleapis.com" in url and any(c in str(exc) for c in ("400", "403")):
            msg += "\n→ Gemini API 키(GEMINI_API_KEY)가 비었거나 무효, 또는 API가 사용 설정되지 않음"
        elif "googleapis.com" in url and "404" in str(exc):
            msg += "\n→ GEMINI_MODEL 이름 확인 (기본 gemini-3.8-flash)"
        elif "401" in str(exc):
            msg += "\n→ 워드프레스 응용 프로그램 비밀번호 또는 서버의 Authorization 헤더 전달을 확인"
        print(msg, file=sys.stderr)
        telegram(msg)
        return 1


if __name__ == "__main__":
    sys.exit(safe_main())
