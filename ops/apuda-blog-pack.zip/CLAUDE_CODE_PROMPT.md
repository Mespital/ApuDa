아래를 Claude Code에 그대로 붙여넣는다. (VPS SSH 별칭: hostinger-vps)

---

호스팅어 VPS(hostinger-vps)에 아프다 블로그용 워드프레스를 도커로 추가하려고 한다.
로컬의 `2026-11-19_아프다_블로그설치팩.zip`을 VPS `/home/apuda/`에 올려서 풀고, 그 안의 README.md 순서대로 진행해 줘.

규칙:
- 기존 컨테이너, 기존 크론, Hermes 관련 파일은 절대 건드리지 마.
- hPanel OS 템플릿 변경, `docker system prune`, 다른 compose 프로젝트의 down/restart는 하지 마.
- 0단계 `preflight.sh` 결과를 나한테 먼저 보여주고, 3단계 프록시 방법(A/B/C)은 그 결과를 보고 나한테 확인받은 뒤 진행해.
- 1단계 DNS와 4단계 브라우저 설치는 내가 직접 한다. 그 지점에서 멈추고 알려줘.
- 비밀번호·API 키는 화면에 출력하거나 나한테 보여주지 마. `.env`에만 둬.
- 5단계 `post_setup.sh`의 키트 경로는 `/home/apuda/apuda-wp-kit`.
- 끝나면 `python3 run.py preview bladder/bcg` (API 없이) 결과까지 확인해 줘.
