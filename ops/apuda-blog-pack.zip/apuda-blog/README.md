# 아프다 블로그 설치 (blog.apuda.app, 기존 VPS에 도커로)

이 폴더는 VPS에 워드프레스와 DB를 **별도 컨테이너**로 추가한다.

- Hermes 등 기존 컨테이너, 기존 크론은 건드리지 않는다
- 워드프레스는 서버 내부 포트(127.0.0.1:8081)에만 열린다. 인터넷 연결은 프록시가 맡는다
- hPanel의 "OS 템플릿 변경"은 **쓰지 않는다**. 서버가 초기화된다

## 0. 점검 (읽기만 함)

```bash
cd /home/apuda/apuda-blog && ./preflight.sh
```

여기서 두 가지를 확인한다.
1. **서버 공인 IP**: 다음 단계 DNS에 넣는다
2. **80·443 포트를 누가 쓰는지**: 프록시 방법이 갈린다 (3단계)

## 1. DNS (도메인 산 곳에서)

apuda.app 관리 화면 → DNS 레코드 추가

| 유형 | 호스트 | 값 | TTL |
|---|---|---|---|
| A | blog | 0단계의 공인 IP | 기본값 |

apuda.app 본 사이트(넷틀리파이) 레코드는 그대로 둔다. `blog` 하나만 추가한다.

## 2. 워드프레스 컨테이너 시작

```bash
./setup.sh
```

DB 비밀번호는 자동 생성돼 `.env`(권한 600)에만 저장된다. "워드프레스 응답 OK"가 나오면 다음 단계.

## 3. 도메인 연결 (0단계 결과에 따라 하나만)

**A. 80·443이 비어 있을 때** — Caddy가 인증서까지 자동 처리

```bash
docker compose -f docker-compose.yml -f proxy/caddy-compose.yml up -d caddy
```

**B. 호스트 nginx가 80·443을 쓰고 있을 때**

```bash
sudo cp proxy/nginx-blog.apuda.app.conf /etc/nginx/sites-available/blog.apuda.app
sudo ln -s /etc/nginx/sites-available/blog.apuda.app /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d blog.apuda.app
```

**C. 다른 프록시(Traefik, 다른 Caddy 컨테이너 등)가 쓰고 있을 때**
기존 프록시 설정에 `blog.apuda.app → 127.0.0.1:8081` 한 줄을 추가한다. 이때 `X-Forwarded-Proto`와 `Authorization` 헤더를 넘기게 한다.

## 4. 워드프레스 첫 설치 (브라우저, 네가 직접)

`https://blog.apuda.app/wp-admin/install.php`

- 사이트 제목: 아프다 블로그
- 관리자 아이디·비밀번호: 네가 정한다. 비밀번호는 비밀번호 관리자에 저장
- "검색 엔진이 이 사이트를 색인하지 않도록 합니다": **체크하지 않는다**

## 5. 마무리 설정 + 자동 글쓰기 키트 연결

```bash
./post_setup.sh /home/apuda/apuda-wp-kit
```

한국어, 서울 시간대, 고유주소(글 이름), 댓글 기본 닫기, 편집자 계정 `apuda-bot`을 만든다.
응용 프로그램 비밀번호를 발급해 **키트 `.env`에 바로 써 넣는다** (화면에 안 나옴).
마지막 줄 "REST 인증 확인: HTTP 200"이면 끝.

## 6. 첫 글

```bash
cd /home/apuda/apuda-wp-kit
nano .env          # ANTHROPIC_API_KEY, 텔레그램 값 채우기
python3 run.py preview bladder/bcg --claude
python3 run.py post bladder/bcg
```

텔레그램으로 초안 링크가 오면 워드프레스에서 읽어 보고 공개한다.

## 백업·되돌리기

- 데이터는 전부 `data/` 폴더에 있다. 이 폴더만 백업하면 된다
- 지우려면: `docker compose down` (데이터 유지) / `docker compose down && rm -rf data` (완전 삭제, 되돌릴 수 없음)
