#!/usr/bin/env bash
# 브라우저에서 워드프레스 설치(관리자 계정 생성)를 마친 뒤 한 번 실행.
# 한국어, 고유주소, 댓글 기본 닫기, 편집자 계정과 응용 프로그램 비밀번호를 만들고
# 그 비밀번호를 자동 글쓰기 키트 .env에 바로 써 넣는다. 비밀번호는 화면에 나오지 않는다.
#   사용: ./post_setup.sh /home/apuda/apuda-wp-kit
set -euo pipefail
cd "$(dirname "$0")"
KIT_DIR="${1:?자동 글쓰기 키트 경로를 넣어줘 (예: /home/apuda/apuda-wp-kit)}"
wp() { docker compose --profile cli run --rm -T cli wp "$@"; }
wp core is-installed || { echo "먼저 https://$(grep BLOG_DOMAIN .env | cut -d= -f2)/wp-admin/install.php 에서 설치를 끝내줘" >&2; exit 1; }
wp language core install ko_KR --activate
wp option update timezone_string Asia/Seoul
wp rewrite structure '/%postname%/' --hard
wp option update default_comment_status closed
wp option update default_ping_status closed
if ! wp user get apuda-bot >/dev/null 2>&1; then
  wp user create apuda-bot "apuda-bot@invalid.local" --role=editor --display_name="아프다 편집부" >/dev/null
  echo "편집자 계정 apuda-bot 생성"
fi
APP_PW=$(wp user application-password create apuda-bot "apuda-wp-kit $(date +%F)" --porcelain)
[ -f "$KIT_DIR/.env" ] || cp "$KIT_DIR/.env.example" "$KIT_DIR/.env"
chmod 600 "$KIT_DIR/.env"
DOMAIN=$(grep BLOG_DOMAIN .env | cut -d= -f2)
python3 - "$KIT_DIR/.env" "$DOMAIN" "$APP_PW" <<'PY'
import re, sys
path, domain, pw = sys.argv[1:4]
text = open(path, encoding="utf-8").read()
for key, val in (("WP_SITE_URL", f"https://{domain}"), ("WP_USER", "apuda-bot"), ("WP_APP_PASSWORD", pw)):
    line = f"{key}={val}"
    text = re.sub(rf"^{key}=.*$", line, text, flags=re.M) if re.search(rf"^{key}=", text, re.M) else text + "\n" + line
open(path, "w", encoding="utf-8").write(text)
PY
echo "키트 .env에 WP_SITE_URL·WP_USER·WP_APP_PASSWORD 기록 완료 ($KIT_DIR/.env)"
code=$(curl -s -o /dev/null -w '%{http_code}' -u "apuda-bot:$APP_PW" "https://$DOMAIN/wp-json/wp/v2/users/me")
echo "REST 인증 확인: HTTP $code (200이면 정상, 401이면 프록시가 Authorization 헤더를 막는 것)"
