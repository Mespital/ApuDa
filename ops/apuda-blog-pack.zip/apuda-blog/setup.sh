#!/usr/bin/env bash
# 워드프레스·DB 컨테이너를 만든다. 80·443 포트와 다른 컨테이너는 건드리지 않는다.
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -f .env ]; then
  cat > .env <<ENV
BLOG_DOMAIN=blog.apuda.app
WP_LOCAL_PORT=8081
DB_PASSWORD=$(openssl rand -hex 24)
DB_ROOT_PASSWORD=$(openssl rand -hex 24)
ENV
  chmod 600 .env
  echo ".env 생성 (DB 비밀번호 자동 생성, 화면에 출력하지 않음)"
fi
if (ss -ltn 2>/dev/null || netstat -ltn) | grep -q ":$(grep WP_LOCAL_PORT .env | cut -d= -f2) "; then
  echo "내부 포트가 이미 사용 중. .env의 WP_LOCAL_PORT를 비어 있는 번호로 바꾸고 다시 실행" >&2; exit 1
fi
mkdir -p data/db data/wp
docker compose up -d db wordpress
echo "기다리는 중..."
for i in $(seq 1 30); do
  code=$(curl -s -o /dev/null -w '%{http_code}' -H 'X-Forwarded-Proto: https' "http://127.0.0.1:$(grep WP_LOCAL_PORT .env | cut -d= -f2)/wp-admin/install.php" || true)
  [ "$code" = "200" ] && { echo "워드프레스 응답 OK (서버 내부). 다음: proxy/ 안내대로 도메인 연결"; exit 0; }
  sleep 3
done
echo "응답이 없음. docker compose logs wordpress 로 확인" >&2; exit 1
