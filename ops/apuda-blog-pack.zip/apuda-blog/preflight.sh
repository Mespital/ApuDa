#!/usr/bin/env bash
# 읽기 전용 점검. 아무것도 설치·변경하지 않는다.
echo "== 서버 공인 IP (blog.apuda.app A 레코드에 넣을 값)"
curl -s -4 --max-time 5 https://ifconfig.me || echo "(확인 실패)"; echo
echo "== Docker"
docker --version 2>/dev/null || echo "docker 없음"
docker compose version 2>/dev/null || echo "docker compose 플러그인 없음"
echo "== 80·443 포트를 쓰는 프로그램"
(ss -ltnp 2>/dev/null || netstat -ltnp 2>/dev/null) | awk 'NR==1 || /:80 |:443 /'
echo "== 8081 포트 (워드프레스가 쓸 내부 포트)"
(ss -ltn 2>/dev/null || netstat -ltn 2>/dev/null) | grep -q ':8081 ' && echo "사용 중 — .env의 WP_LOCAL_PORT를 바꿔야 함" || echo "비어 있음"
echo "== 실행 중인 컨테이너"
docker ps --format '{{.Names}}\t{{.Image}}\t{{.Ports}}' 2>/dev/null
echo "== 웹서버"
for s in nginx caddy apache2 traefik; do systemctl is-active --quiet "$s" 2>/dev/null && echo "$s: 실행 중 (호스트)"; done
echo "== 메모리·디스크"
free -h | head -2; df -h / | tail -1
